<?php
namespace App;
use DataFrame\Models\Elegant;
class User extends Elegant{
	
}